<div class="row padding-1 p-1">
    <div class="col-md-12">
        
        <div class="form-group mb-2 mb20">
            <label for="id_nivel_p" class="form-label">{{ __('Id Nivel P') }}</label>
            <input type="text" name="id_nivel_p" class="form-control @error('id_nivel_p') is-invalid @enderror" value="{{ old('id_nivel_p', $nivelesPeso?->id_nivel_p) }}" id="id_nivel_p" placeholder="Id Nivel P">
            {!! $errors->first('id_nivel_p', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>') !!}
        </div>
        <div class="form-group mb-2 mb20">
            <label for="descripcion" class="form-label">{{ __('Descripcion') }}</label>
            <input type="text" name="descripcion" class="form-control @error('descripcion') is-invalid @enderror" value="{{ old('descripcion', $nivelesPeso?->descripcion) }}" id="descripcion" placeholder="Descripcion">
            {!! $errors->first('descripcion', '<div class="invalid-feedback" role="alert"><strong>:message</strong></div>') !!}
        </div>

    </div>
    <div class="col-md-12 mt20 mt-2">
        <button type="submit" class="btn btn-primary">{{ __('Submit') }}</button>
    </div>
</div>