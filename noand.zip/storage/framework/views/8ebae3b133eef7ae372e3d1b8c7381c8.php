<?php $__env->startSection('template_title'); ?>
    <?php echo e($persona->name ?? __('Show') . " " . __('Persona')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
                        <div class="float-left">
                            <span class="card-title"><?php echo e(__('Show')); ?> Persona</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('personas.index')); ?>"> <?php echo e(__('Back')); ?></a>
                        </div>
                    </div>

                    <div class="card-body bg-white">
                        
                                <div class="form-group mb-2 mb20">
                                    <strong>Id Persona:</strong>
                                    <?php echo e($persona->id_persona); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Nombre:</strong>
                                    <?php echo e($persona->nombre); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Apellido P:</strong>
                                    <?php echo e($persona->apellido_p); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Apellido M:</strong>
                                    <?php echo e($persona->apellido_m); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Sexo:</strong>
                                    <?php echo e($persona->sexo); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Curp:</strong>
                                    <?php echo e($persona->curp); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Correo:</strong>
                                    <?php echo e($persona->correo); ?>

                                </div>
                                <div class="form-group mb-2 mb20">
                                    <strong>Contraseña:</strong>
                                    <?php echo e($persona->contraseña); ?>

                                </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/noand/resources/views/persona/show.blade.php ENDPATH**/ ?>