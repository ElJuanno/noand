<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * The path to the "home" route for your application.
     *
     * Typically, users are redirected here after authentication.
     *
     * @var string
     */
    public const HOME = '/home';

    /**
     * Define your route model bindings, pattern filters, and other route configuration.
     */
protected $namespace = 'App\\Http\\Controllers';

  public function boot(): void
{
    $this->routes(function () {
        Route::prefix('api')
            ->middleware('api') // <= Esto está bien
                            ->namespace($this->namespace . '\\Api')  // <= 🔥 AGREGA ESTA LÍNEA 🔥
            ->group(base_path('routes/api.php'));

        Route::middleware('web')
            ->namespace($this->namespace) // <= 🔥 AGREGA ESTA TAMBIÉN 🔥
            ->group(base_path('routes/web.php'));
    });
}

}
