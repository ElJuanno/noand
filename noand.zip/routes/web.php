<?php

use Illuminate\Support\Facades\Route;

// Aquí solo van rutas WEB normales si algún día tienes
// vistas, Blade templates, etc. Ahora mismo puedes dejarlo así:

Route::get('/', function () {
    return response()->json(['message' => 'Laravel funcionando correctamente.']);
});

// 🔥 NO debes tener rutas como login, register o personas aquí
// 🔥 NO debe haber rutas que usen AuthController ni PersonasController aquí

