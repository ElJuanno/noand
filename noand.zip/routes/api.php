<?php

use Illuminate\Support\Facades\Route;

Route::get('/prueba-api', function () {
    return response()->json(['ok' => true]);
});

